<!--awal BANNER-->
<div class="col-md-12">
    <img src="{{ asset('gambar') }}/bg.jpeg" width="100%" height="280px">
</div>
<!--akhir BANNER-->